/Users/tommasogiorgeschi/VulkanSDK/1.3.204.1/macOS/bin/glslc Shader.vert -o vert.spv
/Users/tommasogiorgeschi/VulkanSDK/1.3.204.1/macOS/bin/glslc Shader.frag -o frag.spv
/Users/tommasogiorgeschi/VulkanSDK/1.3.204.1/macOS/bin/glslc shader_boat.frag -o frag_boat.spv
